from ForestOps.data.data import api
# Function to write a new entry to data.py
def add_entry_to_data(name, url):
    with open('data.py', 'a') as file:
        file.write(f"\n\napi['{name}'] = {url}\n")

# Call the function to add a new entry
add_entry_to_data('New Organization', "{'New Dataset': 'https://example.com/new_dataset'}")

# Reload the updated data.py file
import importlib
importlib.reload(api)

# Now the 'api' dictionary in data.py has the new entry
print(api)

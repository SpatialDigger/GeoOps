datasources = {
    "NHLE": {
        "ScheduledMonuments": "https://services-eu1.arcgis.com/ZOdPfBS3aqqDYPUQ/arcgis/rest/services/National_Heritage_List_for_England_NHLE/FeatureServer/3/query?outFields=*&where=1%3D1&f=geojson",

    }

}